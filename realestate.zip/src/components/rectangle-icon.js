import { memo } from "react";

const RectangleIcon = memo(() => {
  return (
    <img
      className="absolute top-[0px] left-[0px] w-[2961px] h-[1501.6px] object-cover"
      alt=""
      src="/rectangle-1@2x.png"
    />
  );
});

export default RectangleIcon;
