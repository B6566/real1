import { memo } from "react";

const ContainerCard = memo(() => {
  return (
    <div className="absolute top-[150.83px] left-[calc(50%_-_1192.48px)] w-[2462.85px] h-[74.17px] text-left text-31xl text-black font-montserrat">
      <b className="absolute top-[14px] left-[0px]">AG REAL-ESTATE</b>
      <div className="absolute top-[20px] left-[715px]">
        <b>HOME</b>
        <span>{` `}</span>
      </div>
      <b className="absolute top-[20px] left-[952px]">RENT</b>
      <b className="absolute top-[8px] left-[1175px]">
        <span>SELL</span>
        <span className="text-41xl">{` `}</span>
      </b>
      <b className="absolute top-[20px] left-[1393px]">BUY</b>
      <b className="absolute top-[20px] left-[1587px] text-28xl">FINANCE</b>
      <b className="absolute top-[18px] left-[1905px] text-28xl inline-block w-[196px] h-[71px]">
        INSURE
      </b>
      <div className="absolute top-[-13px] left-[2168px] w-[263px] h-[114px] text-26xl">
        <img
          className="absolute top-[0px] left-[0px] rounded-16xl w-[263px] h-[114px]"
          alt=""
          src="/rectangle-2.svg"
        />
        <b className="absolute top-[27px] left-[40px]">SIGNUP</b>
      </div>
    </div>
  );
});

export default ContainerCard;
