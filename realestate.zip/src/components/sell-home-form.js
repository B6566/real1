import { memo } from "react";

const SellHomeForm = memo(() => {
  return (
    <div className="absolute top-[1212.31px] left-[812px] w-[1843px] h-[290px] text-left text-26xl text-black font-montserrat">
      <div className="absolute top-[0px] left-[671px] w-[511px] h-[290px]">
        <div className="absolute top-[0px] left-[0px] rounded-t-31xl rounded-b-none bg-rosybrown w-[511px] h-[290px]" />
        <b className="absolute top-[179.27px] left-[54px] inline-block w-[359px] h-[48.33px]">
          {" "}
          SELL A HOME
        </b>
        <img
          className="absolute top-[55.36px] left-[184px] w-24 h-[84.36px] object-cover"
          alt=""
          src="/sell-stock@2x.png"
        />
      </div>
      <div className="absolute top-[0px] left-[0px] w-[553px] h-[290px]">
        <div className="absolute top-[0px] left-[0px] rounded-t-31xl rounded-b-none bg-rosybrown w-[553px] h-[290px]" />
        <img
          className="absolute top-[55.36px] left-[175px] w-[203px] h-[84.36px] object-cover"
          alt=""
          src="/property1@2x.png"
        />
        <b className="absolute top-[184.55px] left-[111px] inline-block w-[308px] h-[96.67px]">
          <p className="m-0">BUY A HOME</p>
        </b>
      </div>
      <div className="absolute top-[0px] left-[1297px] w-[546px] h-[290px]">
        <div className="absolute top-[0px] left-[0px] rounded-t-31xl rounded-b-none bg-rosybrown w-[546px] h-[290px]" />
        <img
          className="absolute top-[55.36px] left-[209px] w-24 h-[84.36px] object-cover"
          alt=""
          src="/bungalow@2x.png"
        />
        <b className="absolute top-[179.27px] left-[105px] inline-block w-[335px] h-[48.33px]">
          RENT A HOME
        </b>
      </div>
    </div>
  );
});

export default SellHomeForm;
