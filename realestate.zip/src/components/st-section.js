import { memo } from "react";
import RectangleIcon from "./rectangle-icon";
import ContainerCard from "./container-card";
import SellHomeForm from "./sell-home-form";

const StSection = memo(() => {
  return (
    <div className="absolute top-[0px] left-[0px] w-[2961px] h-[1502.31px] text-left text-31xl text-black font-montserrat">
      <RectangleIcon />
      <ContainerCard />
      <div className="absolute top-[652.5px] left-[98.03px] w-[960.08px] h-[385.83px]">
        <div className="absolute top-[265px] left-[58px] w-[950px] h-[141px]">
          <img
            className="absolute top-[0px] left-[-4px] rounded-31xl w-[958px] h-[149px]"
            alt=""
            src="/rectangle-3.svg"
          />
          <div className="absolute top-[41px] left-[74px] inline-block w-[175.87px] h-[57.62px]">{`Search `}</div>
          <img
            className="absolute top-[18.98px] left-[757.94px] w-[192.06px] h-[103.04px] object-cover"
            alt=""
            src="/search@2x.png"
          />
        </div>
        <div className="absolute top-[23px] left-[58px] text-66xl font-extrabold inline-block w-[876px] text-crimson">
          <span>FIND YOUR</span>
          {` `}
          <span>DREAM</span>
          <span className="text-black"> HOME HERE!</span>
        </div>
      </div>
      <SellHomeForm />
    </div>
  );
});

export default StSection;
